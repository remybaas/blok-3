<ul class="nav nav-pills flex-column">
        <li class="nav-item">
          <a class="nav-link active" href="remy.php">remy</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="werk.php">werk</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="stage.php">stage</a>
        </li>
        <li class="nav-item">
          <a class="nav-link " href="contact.php">contact</a>
        </li>
      </ul>


<style>
  


</style>