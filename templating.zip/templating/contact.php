<?php
require 'includes/db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>templating</title>
  <meta charset="utf-8">
 
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  
</head>
<body style="margin-bottom: 0px;">

<?php
require 'jumbotron.php';
?>

<?php 
require 'navbar.php';
?>


</head>
  <body>
<form action="includes/signup.inc.php" method="post" >
<div class="container">
  <div class="row">
    <div class="col-25">
      <label class="fnametext" for="fname">First Name</label>
    </div>
    <div class="col-75">
      <input type="text" class="fname" name="firstname"  placeholder="Your name..">
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label class="lnametext" for="lname">Last Name</label>
    </div>
    <div class="col-75">
      <input type="text" class="lname" name="lastname"  placeholder="Your last name..">
    </div>
  </div>
  <div class="row">
    <div  class="col-25">
      <label class="emailtext" for="email">E-mail</label>
    </div>
    <div class="col-75">
      <input class="email" name="email"   placeholder="Your E-mail..">
      
      </input>
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label class="subjecttext" for="subject">Subject</label>
    </div>
    <div class="col-75">
      <textarea class="subject" name="subject" placeholder="Write something.." style="height:200px"></textarea>
    </div>
  </div>
  <div class="row">
    <button class="input" type="submit" name="submit" >Send</button>
  </div>
  
</div>
</form>

<?php
  require 'footer.php'
?>

 <style>
       * {
    box-sizing: border-box;
    }
    .container {
      border-radius: 5px;
      background-color: #f2f2f2;
      padding: 20px;
      background-color: darkgrey;
      margin-top: 1%;
      margin-bottom: -1.4%;
    }

      input:focus,
      select:focus,
      textarea:focus,
      button:focus {
      outline: none;

    }
    .fnametext , .lnametext , .emailtext , .subjecttext{
      margin-top:0px;
      margin-left: 10px;
      border-style: solid;
      border-size: 0.2px;
      border-color: grey;
      border-radius: 7.5px;
      width: 100px;
      text-align: center;
    }

    .fname , .lname , .email , .subject{
      color: lightgrey;
      width: 100%;
      padding: 12px;
      border: 1px solid #ccc;
      border-radius: 4px;
      resize: vertical;
      background-color: darkgrey;
      border-style: solid;
      border-size: 1px;
      border-color: black;
    }

    

    .input[type=text], select, textarea {
      width: 100%;
      padding: 12px;
      border: 1px solid #ccc;
      border-radius: 4px;
      resize: vertical;
    }

    label {
      padding: 12px 12px 12px 0;
      display: inline-block;
      color: grey;
    }

    .input[type=submit] {
      background-color: #4CAF50;
      color: white;
      padding: 12px 20px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      float: right;
    }

    .input[type=submit]:hover {
      background-color: #45a049;
    }

    .col-25 {
      float: left;
      width: 25%;
      margin-top: 6px;
    }

    .col-75 {
      float: left;
      width: 75%;
      margin-top: 6px;
    }

    /* Clear floats after the columns */
    .row:after {
      content: "";
      display: table;
      clear: both;
    }

    /* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
    @media screen and (max-width: 700px) {
      .col-25, .col-75, input[type=submit] {
        width: 100%;
        margin-top: 0;
        

        }
         .fnametext , .lnametext , .emailtext , .subjecttext{
          display: none;
      }
         .lname , .email , .subject{
          margin-top: 22px;
        }
        .fname{
          margin-top: 7.5px;
        }
       

        }
    }
    </style>


</body>
</html>
