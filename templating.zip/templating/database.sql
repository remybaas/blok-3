

	CREATE TABLE users(
		firstname varchar(50) not null,
		lastname varchar(50) not null,
		email varchar(50) not null,
		subject varchar(50) not null,
		);

	INSERT INTO portocontact (firstname, lastname, email, subject) 	VALUES( 'remy' , 'baas' , 'sufhgwiufw' , 'qwertyuiop')
