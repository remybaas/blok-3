<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<div class="jumbotron text-center" style="margin-bottom:-32px; margin-top: 30px;">
	  <p class="footer">Footer</p>
	</div>

	<style>
		.footer{
			color: coral;
			
		}

	</style>

</body>
</html>


