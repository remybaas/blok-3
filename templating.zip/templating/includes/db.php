<?php
  	
$dbServername = "localhost";
$dbUsername = "root";
$dbPassword = "mysql";
$dbName = "portefolio";

$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);
	return $conn;

	
   


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
echo "Connected successfully";
?>