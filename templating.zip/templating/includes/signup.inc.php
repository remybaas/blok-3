<?php
$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$email = $_POST['email'];
$subject = $_POST['subject'];

include_once 'db.php';
$sql = "INSERT INTO portocontact (firstname, lastname, email, subject) 	VALUES ('$firstname' , '$lastname' , '$email' , '$subject'); ";

mysqli_query($conn, $sql);

header("location: ../contact.php?signup=succes");
?>