<!DOCTYPE html>
<html lang="en">
<head>
  <title>templating</title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="style.css">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  
</head>

  <body style="margin-bottom: 0px;">
   
  <?php
  require 'jumbotron.php';
  ?>

  <?php 
  require 'navbar.php';
  ?>

      <div class="container" style="margin-top:30px">
          <div class="row">
            <div class="col-sm-4">
             
            <div class="fakeimg"> 
                <img class="ik" src="images/ezel.jpg">
            </div>

                
                  <hr class="d-sm-none">
            </div>
            <div class="col-sm-8">
                <h2>Portefolio van Remy Baas</h2>
                <h5>Gemaakt door Remy Baas</h5>
              
                <?php
                  require 'balkinhoud.php';
                  ?>
                  <ul class="nav nav-pills flex-column">
      
<style>
  
a:hover{
  background-color: grey;
  color: red;
}
.active{
  background-color: black;
  color: white;

}

</style>
<?php
                  ?>
            </div>
        </div>
      </div>

    <?php 
      require 'footer.php';
    ?>

  </body>
  <style> 

    .container , body{
      background-color: rgba(0,0,0,.05);
      margin: 0px;
      margin-top: -30px;
    }
    h5 , h2{
      text-align: center;
    }
  .col-sm-4 , .col-sm-8{
    
  }
  </style>
</html>
