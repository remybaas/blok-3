<?php

$times = date('H:i');

?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="style.css">
  	<meta http-equiv="refresh" content="60">
	<title></title>
</head>
	<body>
			<div class="jumbotron text-center" style="margin-bottom:0; margin-top: 0px;">
			  <h1>Mijn Portefolio</h1>
			  <p class="jumbotext"><h2><?php echo $times; ?> <!-- de tijd --></h2></p> 
			</div>

		<style>
			h1{
				color: white;

			}


			.jumbotext{
				color: coral;


			}
			.jumbotron{
				 background-color: rgba(0,0,0,.05);
				margin-top: 30px;
				color: coral;
			
				border-radius: 0px;
				background-image: url(images/amoled.jpg);
				border-top-right-radius: 10px;
				border-top-left-radius: 10px;
			}
		

		</style>
	</body>
</html>

