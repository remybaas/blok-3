<!DOCTYPE html>
<html lang="en">
<head>
  <title>templating</title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="style.css">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  
</head>
<body style="margin-bottom: 0px;">

<?php
require 'jumbotron.php';
?>

<?php 
require 'navbar.php';
?>

<div class="container" style="margin-top:30px">
  <div class="row">
    <div class="col-sm-4">
      <h2>About Me</h2>
      <h5>Photo of me:</h5>
      <div class="fakeimg">Fake Image</div>
      <p>Some text about me in culpa qui officia deserunt mollit anim..</p>
      <h3>Some Links</h3>
      <p>Lorem ipsum dolor sit ame.</p>
      <?php 
        require 'balkinhoud.php';/* side menu aanroepen*/
      ?>
      <hr class="d-sm-none">
    </div>
    <div class="col-sm-8">
      <h2>Welant College Ottoland , VMBO</h2><!-- title -->
      <h5>2013 t/m 2017</h5><!-- date -->
        <div class="fakeimg">
            <img  src="images/download.jfif">
        </div>
      <p>ik heb hier mijn vmbo niveau 2 gehaald en niks gedaan!</p><!-- info -->
      <br>
      <h2>Davinci College Gorinchem , MBO</h2><!-- title -->
      <h5>2017 t/m Heden</h5><!-- date -->
      <div class="fakeimg">
        <img src="images/davinci.png" style="width: 200px; height: 200px;"><!-- image aanroepen van map images -->
      </div>
      <p>opleiding , Applicatie Ontwikkelaar</p><!-- bijlage -->
      <p> ik begon vorig jaar op nveau 2  ict, in een paar maanden ben ik overgeschakeld naar niveau 3 . Toen ik het einde van dat jaar behaald had , heb ik een gesprek gevolgd met meneer Snoek en ben ik over gegaan naar niveau 4.</p>
      <br><br> 
          
      </p>
    </div>
  </div>
</div>

<div class="jumbotron text-center" style="margin-bottom:0">
  <p>Footer</p>
</div>

</body>
</html>
