

<!DOCTYPE html>
<html lang="en">
<head>
  <title>templating</title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="style.css">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  
</head>
<body style="margin-bottom: 0px;">
<?php
require 'jumbotron.php';
?>

<?php 
require 'navbar.php';
?>

<div class="container" style="margin-top:30px">
  <div class="row">
    <div class="col-sm-4">
      <h2>About Me</h2>
      <h5>Dit ben ik in een ezelpak</h5>
      <div class=""> 
          <img class="ik" src="images/ezel.jpg">
      </div>
      <p>Dit ben ik niet!! maar lijkt wel op mij!</p>
      <h3>LEVENS MENU</h3>
      <p>Lekker klikken!!</p>
     <?php 
        require 'balkinhoud.php';
      ?>
      <hr class="d-sm-none">
    </div>
    <div class="col-sm-8">
      <h2>Discord</h2>
      <h5>Dit is mijn logo op discord, oftewel ik ben makkelijk te herkennen!</h5>
      <div class="fakeimg">
         <img class="logo" src="images/logo-orka-Wit-background.jpeg">
      </div>
      <p>Some text..</p>
      <p>Ik ben Remy! Ik woon in Goudriaan, Zit in Gorinchem op school.<br>
          Ik doe de opleiding AO (Applicatie Ontwikkelaar)
          <br>Mijn hobby's zijn :<br> muziek luisteren ,<br> Gamen ,<br> Koken en programmeren.</p>
      <br>
      <h2>TITLE HEADING</h2>
      <h5>Title description, Sep 2, 2017</h5>
      <div class="fakeimg">Fake Image</div>
      <p>Some text..</p>
      <p>Sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>
    </div>
      <div class="col-sm-4 nav-item navbar">
      </div>
  </div>
</div>


<?php
  require 'footer.php'
?>
</body>
</html>
