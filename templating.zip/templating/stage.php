<!DOCTYPE html>
<html lang="en">
<head>
  <title>templating</title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="style.css">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  
</head>

<body style="margin-bottom: 0px;">


<?php
require 'jumbotron.php';
?>

<?php 
require 'navbar.php';
?>

<div class="container" style="margin-top:30px">
  <div class="row">
    <div class="col-sm-4">
      <h2>About Me</h2>
      <h5>Photo of me:</h5>
      <div class="fakeimg">Fake Image</div>
      <p>Some text about me in culpa qui officia deserunt mollit anim..</p>
      <h3>Some Links</h3>
      <p>Lorem ipsum dolor sit ame.</p>
      <?php 
        require 'balkinhoud.php';
      ?>
      <hr class="d-sm-none">
    </div>
    <div class="col-sm-8">
      <h2>mijn stage bedrijven</h2>
      <h5>computer bouw en repareer service</h5>
        <img class="stageimg" src="images/logo.png">
      <p><h2>Promocomputers</h2></p>
      <h3>2013-2015</h3>
      <p>ik heb hier in totaal 2 keer stage gelopen toen ik op het Wellant College Bossekamp , Ottoland zat, ze noemde het snuffelstage. Ik heb daar in ieder geval genoeg gesnuffeld</p>
      <br>
      <div></div>
      <h2>ProdaCom</h2>
        <h5>website ontwikkelaars</h5>
      
          <img class="stageimg" src="images/proda.png">
          <p>ProdaCom</p>

          <p>Ik heb hier een half jjaar elke woensdag stage gelopen toen ik nog op het wellant college zat , ik heb hier alle basics geleerd van html en css, beetje php en javascript.</p>

       <img class="stageimg" src="../image/lip.png">
      <p><h2>Lucom</h2><h5>(moet ik nog beginnen)</h5></p>
      <h5>Vanaf 2-9-2019 tot 5-2-2020</h5>
      <p>dit is een IT Software bedrijf, wat facturen maakt maar ook, formulier websites voor overheden en grote bedrijven. Ik leer hier om zzulke forms te maken.</p>
    </div>
  </div>
</div>

<div class="jumbotron text-center" style="margin-bottom:0">
  <p>Footer</p>
</div>

</body>
</html>